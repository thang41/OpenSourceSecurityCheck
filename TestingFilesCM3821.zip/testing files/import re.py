import re
email = ['username@gmail.com']
#emails: ([a-zA-Z0-9+.-]+@[a-zA-Z0-9.-]+.[a-zA-Z0-9_-]+) code to search
([a-zA-Z0-9+._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)
print('email validation: ')
for i in ssnlist:
    print(bool(re.match(r([a-zA-Z0-9+.-]+@[a-zA-Z0-9.-]+.[a-zA-Z0-9_-]+), i)))
#phone numbers
# /^[.-)( ]([0-9]{3})[.-)( ]([0-9]{3})[.-)( ]*([0-9]{4})$/ 
