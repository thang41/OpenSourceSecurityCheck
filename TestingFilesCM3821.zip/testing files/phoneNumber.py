import re
fname = input("Enter a filename: ")
try:
    found = open(fname)
    for line in found:
        line = line.strip()
        lst = re.findall('(?<!\d)(?:\d{10}|\d{3}-\d{3}-\d{4})(?!\d)', line)
        if (len(lst) > 0):
            print(lst)

except:
    print("No phone numbers found")