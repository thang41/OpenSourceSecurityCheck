import re
fname = input("Enter a filename: ")
try:
    found = open(fname)
    for line in found:
        line = line.strip()
        lst = re.findall('[0-9a-zA-Z]+@[0-9a-zA-Z]+\.[0-9a-zA-Z]+', line)
        if (len(lst) > 0):
            print(lst)

except:
    print("File not found")